package com.example.roomie.house.expenses;

import com.example.roomie.FirestoreJob;

public class CreateNewExpenseJob extends FirestoreJob
{

}
